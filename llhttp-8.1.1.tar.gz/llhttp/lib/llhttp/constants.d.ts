import { IEnumMap } from './utils';
export declare type HTTPMode = 'loose' | 'strict';
export declare enum ERROR {
    OK = 0,
    INTERNAL = 1,
    STRICT = 2,
    CR_EXPECTED = 25,
    LF_EXPECTED = 3,
    UNEXPECTED_CONTENT_LENGTH = 4,
    UNEXPECTED_SPACE = 30,
    CLOSED_CONNECTION = 5,
    INVALID_METHOD = 6,
    INVALID_URL = 7,
    INVALID_CONSTANT = 8,
    INVALID_VERSION = 9,
    INVALID_HEADER_TOKEN = 10,
    INVALID_CONTENT_LENGTH = 11,
    INVALID_CHUNK_SIZE = 12,
    INVALID_STATUS = 13,
    INVALID_EOF_STATE = 14,
    INVALID_TRANSFER_ENCODING = 15,
    CB_MESSAGE_BEGIN = 16,
    CB_HEADERS_COMPLETE = 17,
    CB_MESSAGE_COMPLETE = 18,
    CB_CHUNK_HEADER = 19,
    CB_CHUNK_COMPLETE = 20,
    PAUSED = 21,
    PAUSED_UPGRADE = 22,
    PAUSED_H2_UPGRADE = 23,
    USER = 24,
    CB_URL_COMPLETE = 26,
    CB_STATUS_COMPLETE = 27,
    CB_METHOD_COMPLETE = 32,
    CB_VERSION_COMPLETE = 33,
    CB_HEADER_FIELD_COMPLETE = 28,
    CB_HEADER_VALUE_COMPLETE = 29,
    CB_CHUNK_EXTENSION_NAME_COMPLETE = 34,
    CB_CHUNK_EXTENSION_VALUE_COMPLETE = 35,
    CB_RESET = 31
}
export declare enum TYPE {
    BOTH = 0,
    REQUEST = 1,
    RESPONSE = 2
}
export declare enum FLAGS {
    CONNECTION_KEEP_ALIVE = 1,
    CONNECTION_CLOSE = 2,
    CONNECTION_UPGRADE = 4,
    CHUNKED = 8,
    UPGRADE = 16,
    CONTENT_LENGTH = 32,
    SKIPBODY = 64,
    TRAILING = 128,
    TRANSFER_ENCODING = 512
}
export declare enum LENIENT_FLAGS {
    HEADERS = 1,
    CHUNKED_LENGTH = 2,
    KEEP_ALIVE = 4,
    TRANSFER_ENCODING = 8,
    VERSION = 16
}
export declare enum METHODS {
    DELETE = 0,
    GET = 1,
    HEAD = 2,
    POST = 3,
    PUT = 4,
    CONNECT = 5,
    OPTIONS = 6,
    TRACE = 7,
    COPY = 8,
    LOCK = 9,
    MKCOL = 10,
    MOVE = 11,
    PROPFIND = 12,
    PROPPATCH = 13,
    SEARCH = 14,
    UNLOCK = 15,
    BIND = 16,
    REBIND = 17,
    UNBIND = 18,
    ACL = 19,
    REPORT = 20,
    MKACTIVITY = 21,
    CHECKOUT = 22,
    MERGE = 23,
    'M-SEARCH' = 24,
    NOTIFY = 25,
    SUBSCRIBE = 26,
    UNSUBSCRIBE = 27,
    PATCH = 28,
    PURGE = 29,
    MKCALENDAR = 30,
    LINK = 31,
    UNLINK = 32,
    SOURCE = 33,
    PRI = 34,
    DESCRIBE = 35,
    ANNOUNCE = 36,
    SETUP = 37,
    PLAY = 38,
    PAUSE = 39,
    TEARDOWN = 40,
    GET_PARAMETER = 41,
    SET_PARAMETER = 42,
    REDIRECT = 43,
    RECORD = 44,
    FLUSH = 45
}
export declare const METHODS_HTTP: METHODS[];
export declare const METHODS_ICE: METHODS[];
export declare const METHODS_RTSP: METHODS[];
export declare const METHOD_MAP: IEnumMap;
export declare const H_METHOD_MAP: IEnumMap;
export declare enum STATUSES {
    CONTINUE = 100,
    SWITCHING_PROTOCOLS = 101,
    PROCESSING = 102,
    EARLY_HINTS = 103,
    RESPONSE_IS_STALE = 110,
    REVALIDATION_FAILED = 111,
    DISCONNECTED_OPERATION = 112,
    HEURISTIC_EXPIRATION = 113,
    MISCELLANEOUS_WARNING = 199,
    OK = 200,
    CREATED = 201,
    ACCEPTED = 202,
    NON_AUTHORITATIVE_INFORMATION = 203,
    NO_CONTENT = 204,
    RESET_CONTENT = 205,
    PARTIAL_CONTENT = 206,
    MULTI_STATUS = 207,
    ALREADY_REPORTED = 208,
    TRANSFORMATION_APPLIED = 214,
    IM_USED = 226,
    MISCELLANEOUS_PERSISTENT_WARNING = 299,
    MULTIPLE_CHOICES = 300,
    MOVED_PERMANENTLY = 301,
    FOUND = 302,
    SEE_OTHER = 303,
    NOT_MODIFIED = 304,
    USE_PROXY = 305,
    SWITCH_PROXY = 306,
    TEMPORARY_REDIRECT = 307,
    PERMANENT_REDIRECT = 308,
    BAD_REQUEST = 400,
    UNAUTHORIZED = 401,
    PAYMENT_REQUIRED = 402,
    FORBIDDEN = 403,
    NOT_FOUND = 404,
    METHOD_NOT_ALLOWED = 405,
    NOT_ACCEPTABLE = 406,
    PROXY_AUTHENTICATION_REQUIRED = 407,
    REQUEST_TIMEOUT = 408,
    CONFLICT = 409,
    GONE = 410,
    LENGTH_REQUIRED = 411,
    PRECONDITION_FAILED = 412,
    PAYLOAD_TOO_LARGE = 413,
    URI_TOO_LONG = 414,
    UNSUPPORTED_MEDIA_TYPE = 415,
    RANGE_NOT_SATISFIABLE = 416,
    EXPECTATION_FAILED = 417,
    IM_A_TEAPOT = 418,
    PAGE_EXPIRED = 419,
    ENHANCE_YOUR_CALM = 420,
    MISDIRECTED_REQUEST = 421,
    UNPROCESSABLE_ENTITY = 422,
    LOCKED = 423,
    FAILED_DEPENDENCY = 424,
    TOO_EARLY = 425,
    UPGRADE_REQUIRED = 426,
    PRECONDITION_REQUIRED = 428,
    TOO_MANY_REQUESTS = 429,
    REQUEST_HEADER_FIELDS_TOO_LARGE_UNOFFICIAL = 430,
    REQUEST_HEADER_FIELDS_TOO_LARGE = 431,
    LOGIN_TIMEOUT = 440,
    NO_RESPONSE = 444,
    RETRY_WITH = 449,
    BLOCKED_BY_PARENTAL_CONTROL = 450,
    UNAVAILABLE_FOR_LEGAL_REASONS = 451,
    CLIENT_CLOSED_LOAD_BALANCED_REQUEST = 460,
    INVALID_X_FORWARDED_FOR = 463,
    REQUEST_HEADER_TOO_LARGE = 494,
    SSL_CERTIFICATE_ERROR = 495,
    SSL_CERTIFICATE_REQUIRED = 496,
    HTTP_REQUEST_SENT_TO_HTTPS_PORT = 497,
    INVALID_TOKEN = 498,
    CLIENT_CLOSED_REQUEST = 499,
    INTERNAL_SERVER_ERROR = 500,
    NOT_IMPLEMENTED = 501,
    BAD_GATEWAY = 502,
    SERVICE_UNAVAILABLE = 503,
    GATEWAY_TIMEOUT = 504,
    HTTP_VERSION_NOT_SUPPORTED = 505,
    VARIANT_ALSO_NEGOTIATES = 506,
    INSUFFICIENT_STORAGE = 507,
    LOOP_DETECTED = 508,
    BANDWIDTH_LIMIT_EXCEEDED = 509,
    NOT_EXTENDED = 510,
    NETWORK_AUTHENTICATION_REQUIRED = 511,
    WEB_SERVER_UNKNOWN_ERROR = 520,
    WEB_SERVER_IS_DOWN = 521,
    CONNECTION_TIMEOUT = 522,
    ORIGIN_IS_UNREACHABLE = 523,
    TIMEOUT_OCCURED = 524,
    SSL_HANDSHAKE_FAILED = 525,
    INVALID_SSL_CERTIFICATE = 526,
    RAILGUN_ERROR = 527,
    SITE_IS_OVERLOADED = 529,
    SITE_IS_FROZEN = 530,
    IDENTITY_PROVIDER_AUTHENTICATION_ERROR = 561,
    NETWORK_READ_TIMEOUT = 598,
    NETWORK_CONNECT_TIMEOUT = 599
}
export declare const STATUSES_HTTP: STATUSES[];
export declare enum FINISH {
    SAFE = 0,
    SAFE_WITH_CB = 1,
    UNSAFE = 2
}
export declare type CharList = Array<string | number>;
export declare const ALPHA: CharList;
export declare const NUM_MAP: {
    0: number;
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
    6: number;
    7: number;
    8: number;
    9: number;
};
export declare const HEX_MAP: {
    0: number;
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
    6: number;
    7: number;
    8: number;
    9: number;
    A: number;
    B: number;
    C: number;
    D: number;
    E: number;
    F: number;
    a: number;
    b: number;
    c: number;
    d: number;
    e: number;
    f: number;
};
export declare const NUM: CharList;
export declare const ALPHANUM: CharList;
export declare const MARK: CharList;
export declare const USERINFO_CHARS: CharList;
export declare const STRICT_URL_CHAR: CharList;
export declare const URL_CHAR: CharList;
export declare const HEX: CharList;
export declare const STRICT_TOKEN: CharList;
export declare const TOKEN: CharList;
export declare const HEADER_CHARS: CharList;
export declare const CONNECTION_TOKEN_CHARS: CharList;
export declare const QUOTED_STRING: CharList;
export declare const MAJOR: {
    0: number;
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
    6: number;
    7: number;
    8: number;
    9: number;
};
export declare const MINOR: {
    0: number;
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
    6: number;
    7: number;
    8: number;
    9: number;
};
export declare enum HEADER_STATE {
    GENERAL = 0,
    CONNECTION = 1,
    CONTENT_LENGTH = 2,
    TRANSFER_ENCODING = 3,
    UPGRADE = 4,
    CONNECTION_KEEP_ALIVE = 5,
    CONNECTION_CLOSE = 6,
    CONNECTION_UPGRADE = 7,
    TRANSFER_ENCODING_CHUNKED = 8
}
export declare const SPECIAL_HEADERS: {
    connection: HEADER_STATE;
    'content-length': HEADER_STATE;
    'proxy-connection': HEADER_STATE;
    'transfer-encoding': HEADER_STATE;
    upgrade: HEADER_STATE;
};
